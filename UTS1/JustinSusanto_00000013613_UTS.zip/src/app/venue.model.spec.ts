import { Venue } from './venue.model';

describe('Venue', () => {
  it('should create an instance', () => {
    expect(new Venue()).toBeTruthy();
  });
});
