import { Component, OnInit } from '@angular/core';
import {PlacesService} from "../../place/places.service";
import {ActivatedRoute} from "@angular/router";
import {Place} from "../../place/place.model";

@Component({
  selector: 'app-create-booking',
  templateUrl: './create-booking.component.html',
  styleUrls: ['./create-booking.component.scss'],
})
export class CreateBookingComponent implements OnInit {

  places: Place;

  constructor(private place: PlacesService, private activatedRoute: ActivatedRoute){}

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(
        paramMapper => {
          if(!paramMapper.has('placeId')){return ;}
          this.places = this.place.getDataById(paramMapper.get('placeId'));
        }
    );
  }

}
