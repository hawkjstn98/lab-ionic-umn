import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-booking',
  templateUrl: './offer-booking.page.html',
  styleUrls: ['./offer-booking.page.scss'],
})
export class OfferBookingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
