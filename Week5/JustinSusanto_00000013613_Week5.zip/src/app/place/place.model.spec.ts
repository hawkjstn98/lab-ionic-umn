import { Place } from './place.model';

describe('Place', () => {
  it('should create an instance', () => {
    expect(new Place()).toBeTruthy();
  });
});
